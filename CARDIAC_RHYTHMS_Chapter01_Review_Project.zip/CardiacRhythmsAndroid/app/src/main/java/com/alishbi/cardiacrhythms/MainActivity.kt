package com.alishbi.cardiacrhythms

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import android.content.Context
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

private val Navy = Color(0xFF081827)
private val Panel = Color(0xFF11283A)
private val Red = Color(0xFFFF526B)
private val Muted = Color(0xFF9EB2C3)

private fun savedLanguage(context: Context): String? =
    context.getSharedPreferences("cardiac_prefs", Context.MODE_PRIVATE)
        .getString("language", null)

private fun saveLanguage(context: Context, language: String) {
    context.getSharedPreferences("cardiac_prefs", Context.MODE_PRIVATE)
        .edit().putString("language", language).apply()
}

private val rhythms = listOf(
    Rhythm("Normal Sinus Rhythm", "Regular", "60–100 bpm", "A P wave precedes every QRS; constant PR interval; narrow QRS.", "Normal sinus node activity. Interpret in clinical context."),
    Rhythm("Sinus Bradycardia", "Regular", "<60 bpm", "Sinus P waves before each QRS with a slow rate.", "Assess symptoms, perfusion and reversible causes."),
    Rhythm("Sinus Tachycardia", "Regular", ">100 bpm", "Normal sinus P waves with a faster rate, usually narrow QRS.", "Look for causes such as fever, pain, hypovolemia or hypoxia."),
    Rhythm("Atrial Fibrillation", "Irregularly irregular", "Variable", "No distinct repeating P waves; irregularly irregular R-R intervals.", "Assess stability and stroke-risk pathway with the treating team."),
    Rhythm("Atrial Flutter", "Often regular/variable", "Variable", "Saw-tooth flutter waves; ventricular response depends on conduction ratio.", "Assess rate, symptoms and hemodynamic stability."),
    Rhythm("SVT", "Usually regular", "Often 150–250 bpm", "Typically narrow-complex regular tachycardia; P waves may be hidden.", "Check stability first; follow current local/ACLS protocol."),
    Rhythm("Ventricular Tachycardia", "Usually regular", "Often >100 bpm", "Wide-complex tachycardia; may have AV dissociation or capture/fusion beats.", "Potentially life-threatening. Urgent expert assessment; assess pulse and stability."),
    Rhythm("Ventricular Fibrillation", "Chaotic", "Not measurable", "Disorganized waveform without identifiable P-QRS-T complexes.", "Cardiac arrest rhythm: activate emergency response and follow current resuscitation protocol."),
    Rhythm("First-Degree AV Block", "Usually regular", "Variable", "PR interval >200 ms, with every P wave conducted.", "Correlate with symptoms, medicines and clinical context."),
    Rhythm("Mobitz I (Wenckebach)", "Grouped beats", "Variable", "Progressive PR prolongation followed by a non-conducted P wave.", "Assess symptoms and monitor for progression."),
    Rhythm("Mobitz II", "May be regular/irregular", "Variable", "Intermittent non-conducted P waves without progressive PR lengthening.", "Potential to progress; prompt clinical assessment is important."),
    Rhythm("Third-Degree AV Block", "Atrial/ventricular independent", "Variable", "P waves and QRS complexes occur independently (AV dissociation).", "Urgent assessment, especially with symptoms or poor perfusion.")
)
data class Rhythm(val name:String, val regularity:String, val rate:String, val ecg:String, val note:String)

private val translations = mapOf(
    "appSubtitle" to "A practical ECG learning companion",
    "home" to "Home", "chapter" to "Chapter 01", "library" to "Library", "quiz" to "Quiz", "about" to "About",
    "welcome" to "WELCOME TO", "learnLine" to "Learn. Recognize. Review.",
    "dedication" to "Made with love for Alishbi ❤️",
    "dashboard" to "LEARNING DASHBOARD", "rhythms" to "Rhythms",
    "practiceQs" to "Practice Qs", "explore" to "Explore Rhythm Library",
    "startQuiz" to "Start Quick Quiz", "safetyShort" to "Educational use only. Not a diagnostic or treatment tool.",
    "search" to "Search rhythms...", "back" to "Back to library",
    "questionCheck" to "QUICK KNOWLEDGE CHECK", "question" to "Question",
    "of" to "of", "next" to "Next question", "score" to "Score",
    "regularity" to "Regularity", "typicalRate" to "Typical rate",
    "ecgFeatures" to "ECG features", "learningNote" to "Learning note",
    "aboutTitle" to "About this app", "aboutText" to "CARDIAC RHYTHMS is an educational prototype designed to help learners revise common ECG rhythm patterns.",
    "safetyNote" to "Rhythm descriptions are simplified learning summaries. They do not replace formal ECG training, clinician interpretation, local protocols or emergency services.",
    "version" to "Version 1.0 • Offline starter build",
    "chooseLanguage" to "Choose your language", "languageHint" to "You can change this later in Settings.",
    "continue" to "Continue", "byline" to "By RN IBRAR"
)
private val urdu = mapOf(
    "appSubtitle" to "ECG سیکھنے کے لیے ایک عملی ساتھی",
    "home" to "ہوم", "chapter" to "باب 01", "library" to "لائبریری", "quiz" to "کوئز", "about" to "تعارف",
    "welcome" to "خوش آمدید", "learnLine" to "سیکھیں۔ پہچانیں۔ دہرائیں۔",
    "dedication" to "Alishbi کے لیے محبت کے ساتھ ❤️",
    "dashboard" to "تعلیمی ڈیش بورڈ", "rhythms" to "ردھمز",
    "practiceQs" to "مشق کے سوالات", "explore" to "ECG Rhythm لائبریری دیکھیں",
    "startQuiz" to "کوئز شروع کریں", "safetyShort" to "صرف تعلیمی مقصد کے لیے۔ تشخیص یا علاج کا متبادل نہیں۔",
    "search" to "Rhythms تلاش کریں...", "back" to "لائبریری میں واپس جائیں",
    "questionCheck" to "مختصر معلوماتی کوئز", "question" to "سوال",
    "of" to "میں سے", "next" to "اگلا سوال", "score" to "اسکور",
    "regularity" to "باقاعدگی", "typicalRate" to "عام رفتار",
    "ecgFeatures" to "ECG خصوصیات", "learningNote" to "تعلیمی نوٹ",
    "aboutTitle" to "اس ایپ کے بارے میں", "aboutText" to "CARDIAC RHYTHMS ایک تعلیمی ایپ کا ابتدائی نمونہ ہے جو عام ECG Rhythms کی پہچان اور دہرائی میں مدد دیتا ہے۔",
    "safetyNote" to "Rhythm کی وضاحتیں مختصر تعلیمی خلاصے ہیں۔ یہ باقاعدہ ECG تربیت، ڈاکٹر کی تشریح، مقامی پروٹوکول یا ایمرجنسی سروسز کا متبادل نہیں۔",
    "version" to "ورژن 1.0 • آف لائن ابتدائی ایپ",
    "chooseLanguage" to "اپنی زبان منتخب کریں", "languageHint" to "آپ بعد میں بھی زبان تبدیل کر سکتے ہیں۔",
    "continue" to "جاری رکھیں", "byline" to "By RN IBRAR"
)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { CardiacApp(this) }
    }
}

@Composable
fun CardiacApp(context: Context) {
    var language by remember { mutableStateOf(savedLanguage(context)) }
    var tab by remember { mutableStateOf("Home") }
    var selected by remember { mutableStateOf<Rhythm?>(null) }
    var search by remember { mutableStateOf("") }
    var quizIndex by remember { mutableIntStateOf(0) }
    var score by remember { mutableIntStateOf(0) }
    var answered by remember { mutableStateOf(false) }
    val isUrdu = language == "Urdu"
    fun tr(key: String) = (if (isUrdu) urdu[key] else translations[key]) ?: key

    val questions = listOf(
        Triple("Which rhythm is classically described as irregularly irregular with no distinct repeating P waves?", "Atrial Fibrillation", listOf("Sinus Bradycardia","Atrial Fibrillation","First-Degree AV Block")),
        Triple("A PR interval greater than 200 ms with every P wave conducted suggests:", "First-Degree AV Block", listOf("Mobitz II","First-Degree AV Block","Ventricular Fibrillation")),
        Triple("Which rhythm is a chaotic waveform with no identifiable organized QRS complexes?", "Ventricular Fibrillation", listOf("Atrial Flutter","Normal Sinus Rhythm","Ventricular Fibrillation"))
    )

    MaterialTheme(colorScheme = darkColorScheme(
        primary = Red, background = Navy, surface = Panel, onBackground = Color.White,
        onSurface = Color.White, secondary = Muted
    )) {
        if (language == null) {
            LanguageChooser(
                onChoose = { chosen -> language = chosen; saveLanguage(context, chosen) }
            )
        } else {
            Scaffold(
                containerColor = Navy,
                bottomBar = {
                    NavigationBar(containerColor = Panel) {
                        listOf("Home","Chapter","Library","Quiz","About").forEach { item ->
                            val label = when(item) {
                                "Home" -> tr("home"); "Chapter" -> tr("chapter"); "Library" -> tr("library")
                                "Quiz" -> tr("quiz"); else -> tr("about")
                            }
                            NavigationBarItem(
                                selected = tab == item,
                                onClick = { tab = item; selected = null },
                                icon = { Icon(when(item) {
                                    "Home" -> Icons.Default.Home
                                    "Chapter" -> Icons.Default.Description
                                    "Library" -> Icons.Default.MenuBook
                                    "Quiz" -> Icons.Default.Quiz
                                    else -> Icons.Default.Favorite
                                }, contentDescription = label) },
                                label = { Text(label) }
                            )
                        }
                    }
                }
            ) { padding ->
                Column(
                    Modifier.fillMaxSize().padding(padding).padding(horizontal=18.dp),
                    horizontalAlignment = if (isUrdu) Alignment.End else Alignment.Start
                ) {
                    Spacer(Modifier.height(16.dp))
                    Row(verticalAlignment=Alignment.CenterVertically) {
                        Column(Modifier.weight(1f)) {
                            Text("CARDIAC RHYTHMS", color=Color.White, fontSize=21.sp, fontWeight=FontWeight.Bold)
                            Text(tr("appSubtitle"), color=Muted, fontSize=12.sp)
                        }
                        Text("🫀", fontSize=30.sp)
                    }
                    Spacer(Modifier.height(16.dp))
                    when(tab) {
                        "Home" -> HomeScreen(::tr, isUrdu, { tab="Library" }, { tab="Quiz" }, { tab="Chapter" })
                        "Chapter" -> ChapterOneScreen(isUrdu)
                        "Library" -> {
                            if (selected != null) RhythmDetail(selected!!, ::tr, isUrdu) { selected=null }
                            else {
                                OutlinedTextField(
                                    value=search, onValueChange={search=it}, modifier=Modifier.fillMaxWidth(),
                                    placeholder={ Text(tr("search")) }, leadingIcon={ Icon(Icons.Default.Search,null) },
                                    singleLine=true,
                                    colors=OutlinedTextFieldDefaults.colors(
                                        focusedTextColor=Color.White, unfocusedTextColor=Color.White,
                                        focusedBorderColor=Red, unfocusedBorderColor=Muted,
                                        focusedPlaceholderColor=Muted, unfocusedPlaceholderColor=Muted
                                    )
                                )
                                Spacer(Modifier.height(12.dp))
                                LazyColumn(verticalArrangement=Arrangement.spacedBy(10.dp)) {
                                    items(rhythms.filter { it.name.contains(search,true) }) { rhythm ->
                                        RhythmCard(rhythm) { selected=rhythm }
                                    }
                                }
                            }
                        }
                        "Quiz" -> {
                            val q=questions[quizIndex % questions.size]
                            Text(tr("questionCheck"), color=Red, fontWeight=FontWeight.Bold, fontSize=12.sp)
                            Spacer(Modifier.height(12.dp))
                            Card(colors=CardDefaults.cardColors(containerColor=Panel)) {
                                Column(Modifier.padding(18.dp)) {
                                    Text("${tr("question")} ${(quizIndex % questions.size)+1} ${tr("of")} ${questions.size}", color=Muted)
                                    Spacer(Modifier.height(12.dp))
                                    Text(q.first, fontSize=18.sp, fontWeight=FontWeight.SemiBold)
                                    Spacer(Modifier.height(16.dp))
                                    q.third.forEach { option ->
                                        Button(onClick={ if(!answered){answered=true;if(option==q.second)score++} },
                                            modifier=Modifier.fillMaxWidth().padding(vertical=4.dp),
                                            colors=ButtonDefaults.buttonColors(containerColor=Panel)) { Text(option) }
                                    }
                                    if(answered) {
                                        Text("Correct answer: ${q.second}", color=Red)
                                        Spacer(Modifier.height(8.dp))
                                        Button(onClick={quizIndex++;answered=false}) { Text(tr("next")) }
                                    }
                                }
                            }
                            Spacer(Modifier.height(12.dp))
                            Text("${tr("score")}: $score", color=Muted)
                        }
                        else -> AboutScreen(::tr)
                    }
                }
            }
        }
    }
}

@Composable
fun LanguageChooser(onChoose:(String)->Unit) {
    Column(
        Modifier.fillMaxSize().background(Navy).padding(24.dp),
        horizontalAlignment=Alignment.CenterHorizontally,
        verticalArrangement=Arrangement.Center
    ) {
        Text("🫀", fontSize=64.sp)
        Spacer(Modifier.height(18.dp))
        Text("CARDIAC RHYTHMS", color=Color.White, fontSize=27.sp, fontWeight=FontWeight.ExtraBold)
        Text("For Alishbi ❤️", color=Red, fontSize=20.sp, fontWeight=FontWeight.SemiBold)
        Spacer(Modifier.height(8.dp))
        Text("By RN IBRAR", color=Muted, fontSize=14.sp)
        Spacer(Modifier.height(42.dp))
        Text("Choose your language", color=Color.White, fontSize=22.sp, fontWeight=FontWeight.Bold)
        Text("اپنی زبان منتخب کریں", color=Muted, fontSize=19.sp)
        Spacer(Modifier.height(24.dp))
        Button(onClick={onChoose("Urdu")}, modifier=Modifier.fillMaxWidth().height(56.dp)) {
            Text("1. اردو", fontSize=20.sp)
        }
        Spacer(Modifier.height(12.dp))
        OutlinedButton(onClick={onChoose("English")}, modifier=Modifier.fillMaxWidth().height(56.dp)) {
            Text("2. English", fontSize=20.sp, color=Color.White)
        }
    }
}

@Composable
fun HomeScreen(tr:(String)->String, isUrdu:Boolean, onLibrary:()->Unit, onQuiz:()->Unit, onChapter:()->Unit) {
    Card(colors=CardDefaults.cardColors(containerColor=Panel), shape=RoundedCornerShape(22.dp)) {
        Column(Modifier.padding(20.dp)) {
            Text(tr("welcome"), color=Muted, fontSize=12.sp, fontWeight=FontWeight.Bold)
            Text("Cardiac Rhythms 🫀", color=Color.White, fontSize=27.sp, fontWeight=FontWeight.Bold)
            Text(tr("learnLine"), color=Red, fontSize=14.sp)
            Spacer(Modifier.height(18.dp))
            EcgWave()
            Spacer(Modifier.height(18.dp))
            Text(tr("dedication"), color=Color.White, fontSize=14.sp)
        }
    }
    Spacer(Modifier.height(18.dp))
    Text(tr("dashboard"), color=Muted, fontSize=12.sp, fontWeight=FontWeight.Bold)
    Spacer(Modifier.height(10.dp))
    Row(horizontalArrangement=Arrangement.spacedBy(10.dp)) {
        StatCard("12",tr("rhythms"),Modifier.weight(1f))
        StatCard("3",tr("practiceQs"),Modifier.weight(1f))
    }
    Spacer(Modifier.height(14.dp))
    Button(onClick=onChapter, modifier=Modifier.fillMaxWidth()) {
        Icon(Icons.Default.Description,null); Spacer(Modifier.width(8.dp)); Text(if(isUrdu) "Chapter 01 — Introduction to ECG" else "Chapter 01 — Introduction to ECG")
    }
    OutlinedButton(onClick=onLibrary, modifier=Modifier.fillMaxWidth()) {
        Icon(Icons.Default.MenuBook,null); Spacer(Modifier.width(8.dp)); Text(tr("explore"))
    }
    OutlinedButton(onClick=onQuiz, modifier=Modifier.fillMaxWidth()) {
        Icon(Icons.Default.Quiz,null); Spacer(Modifier.width(8.dp)); Text(tr("startQuiz"))
    }
    Spacer(Modifier.height(10.dp))
    Text(tr("safetyShort"), color=Muted, fontSize=11.sp)
}

@Composable
fun ChapterOneScreen(isUrdu:Boolean) {
    val sections = listOf(
        "1. ECG — Electrocardiography" to "ECG shows electrical signals that are responsible for contractions and relaxation of heart muscles. These electrical impulses are produced by the Sinoatrial (SA) Node.",
        "2. SA Node — Natural Pacemaker" to "It is also called the pacemaker. ‘Pace’ means rate or speed. So, it is the speed controller of the heart, located in the right atrium. It delivers impulses to the AV Node.",
        "3. AV Node" to "The AV Node receives the impulse from the SA Node and conducts it toward the ventricles, with a short delay, so the atria can complete their contraction before the ventricles contract.",
        "4. Contraction and Relaxation" to "Contraction means squeezing. Relaxation means expanding. When the atria contract, the ventricles are relaxed. When the ventricles contract, the atria relax.",
        "5. ECG Waves" to "P Wave: Shows atrial contraction.\n\nQRS Complex: Shows ventricular contraction.\n\nT Wave: Shows ventricular recovery/relaxation. The heart then prepares for the next rhythm cycle.",
        "6. PR Interval" to "The PR interval is measured from the beginning of the P wave to the beginning of the QRS complex. Your notes highlight 0.2 seconds as an important upper limit. A PR interval greater than 0.20 seconds may indicate an AV conduction delay or block.",
        "7. Regularity" to "The rhythm may be regular or irregular. Your notes mention that irregularity or an abnormality in the ventricles may be a sign that needs attention.",
        "8. Bundle Branch Block" to "Bundle branches are part of the conducting network that carries electrical impulses through the ventricles. If conduction through a bundle branch is blocked or delayed, the QRS complex may become wide.",
        "9. QRS Duration" to "Normal QRS duration: 0.08 to 0.12 seconds (80–120 milliseconds).\n\nA QRS duration greater than 0.12 seconds (120 milliseconds) is a wide QRS complex and may be seen with bundle branch block or other causes of delayed ventricular conduction.\n\n1 second = 1000 milliseconds.",
        "10. ST Segment" to "The ST segment is the portion between the end of the QRS complex and the beginning of the T wave. In your notes, it is described as a ‘pause’ or ‘hold’ line while the ventricles are in their recovery phase."
    )
    LazyColumn(verticalArrangement=Arrangement.spacedBy(12.dp), contentPadding=PaddingValues(bottom=20.dp)) {
        item {
            Text(if(isUrdu) "CHAPTER 01" else "CHAPTER 01", color=Red, fontSize=12.sp, fontWeight=FontWeight.Bold)
            Text("Introduction to ECG", color=Color.White, fontSize=25.sp, fontWeight=FontWeight.Bold)
            Text("Prepared from RN IBRAR’s handwritten notes", color=Muted, fontSize=12.sp)
            Spacer(Modifier.height(8.dp))
            EcgWave()
        }
        items(sections) { section ->
            Card(colors=CardDefaults.cardColors(containerColor=Panel), shape=RoundedCornerShape(16.dp)) {
                Column(Modifier.padding(16.dp)) {
                    Text(section.first, color=Red, fontSize=17.sp, fontWeight=FontWeight.Bold)
                    Spacer(Modifier.height(8.dp))
                    Text(section.second, color=Color.White, fontSize=14.sp, lineHeight=21.sp)
                }
            }
        }
        item {
            Text("Study note: This chapter follows the supplied notebook material with only light wording edits for clarity. Clinical interpretation should be checked against formal ECG references and local protocols.", color=Muted, fontSize=11.sp, lineHeight=16.sp)
        }
    }
}

@Composable
fun StatCard(value:String,label:String,modifier:Modifier=Modifier) {
    Card(modifier,colors=CardDefaults.cardColors(containerColor=Panel)) {
        Column(Modifier.padding(16.dp)) {
            Text(value,color=Red,fontSize=25.sp,fontWeight=FontWeight.Bold)
            Text(label,color=Muted,fontSize=12.sp)
        }
    }
}
@Composable
fun RhythmCard(r:Rhythm,onClick:()->Unit) {
    Card(Modifier.fillMaxWidth().clickable{onClick()},colors=CardDefaults.cardColors(containerColor=Panel)) {
        Row(Modifier.padding(16.dp),verticalAlignment=Alignment.CenterVertically) {
            Column(Modifier.weight(1f)) {
                Text(r.name,color=Color.White,fontWeight=FontWeight.SemiBold,fontSize=16.sp)
                Text("${r.regularity} • ${r.rate}",color=Muted,fontSize=12.sp)
            }
            Icon(Icons.Default.ChevronRight,null,tint=Red)
        }
    }
}
@Composable
fun RhythmDetail(r:Rhythm,tr:(String)->String,isUrdu:Boolean,onBack:()->Unit) {
    TextButton(onClick=onBack) { Icon(Icons.Default.ArrowBack,null); Text(" ${tr("back")}") }
    Card(colors=CardDefaults.cardColors(containerColor=Panel)) {
        Column(Modifier.padding(18.dp)) {
            Text(r.name,fontSize=23.sp,fontWeight=FontWeight.Bold)
            Spacer(Modifier.height(10.dp)); EcgWave(); Spacer(Modifier.height(16.dp))
            DetailLine(tr("regularity"),r.regularity)
            DetailLine(tr("typicalRate"),r.rate)
            DetailLine(tr("ecgFeatures"),r.ecg)
            DetailLine(tr("learningNote"),r.note)
        }
    }
}
@Composable
fun DetailLine(label:String,value:String) {
    Text(label.uppercase(),color=Red,fontSize=11.sp,fontWeight=FontWeight.Bold)
    Text(value,color=Color.White,fontSize=14.sp)
    Spacer(Modifier.height(12.dp))
}
@Composable
fun EcgWave() {
    Canvas(Modifier.fillMaxWidth().height(76.dp).background(Color(0xFF0B1F2D),RoundedCornerShape(12.dp)).padding(8.dp)) {
        val p=Path().apply {
            moveTo(0f,size.height*.55f); lineTo(size.width*.16f,size.height*.55f)
            lineTo(size.width*.20f,size.height*.45f); lineTo(size.width*.24f,size.height*.55f)
            lineTo(size.width*.31f,size.height*.55f); lineTo(size.width*.35f,size.height*.12f)
            lineTo(size.width*.39f,size.height*.90f); lineTo(size.width*.44f,size.height*.55f)
            lineTo(size.width*.58f,size.height*.55f); lineTo(size.width*.64f,size.height*.40f)
            lineTo(size.width*.70f,size.height*.55f); lineTo(size.width,size.height*.55f)
        }
        drawPath(p,Red,style=androidx.compose.ui.graphics.drawscope.Stroke(width=4f))
    }
}
@Composable
fun AboutScreen(tr:(String)->String) {
    Card(colors=CardDefaults.cardColors(containerColor=Panel)) {
        Column(Modifier.padding(20.dp)) {
            Text(tr("aboutTitle"),fontSize=22.sp,fontWeight=FontWeight.Bold)
            Spacer(Modifier.height(10.dp)); Text(tr("aboutText"),color=Color.White)
            Spacer(Modifier.height(12.dp)); Text("For Alishbi ❤️",color=Red,fontWeight=FontWeight.Bold)
            Spacer(Modifier.height(12.dp)); Text(tr("safetyNote"),color=Muted,fontSize=12.sp)
            Spacer(Modifier.height(10.dp)); Text(tr("version"),color=Muted,fontSize=11.sp)
        }
    }
}

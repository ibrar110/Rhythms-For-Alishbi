# CARDIAC RHYTHMS — Android starter project

A first offline Android learning-app prototype dedicated to Alishbi.

## Included in Version 1.0 starter
- Dark navy / ECG-red interface
- Home dashboard and ECG waveform graphic
- Searchable library with 12 common rhythm summaries
- Rhythm detail pages
- Small interactive quiz
- About and educational safety note

## Build an APK
1. Install Android Studio (current stable version) on a computer.
2. Open this folder in Android Studio.
3. Allow Gradle sync and install Android SDK Platform 35 if prompted.
4. Connect an Android phone or start an emulator.
5. Select **Build > Build Bundle(s) / APK(s) > Build APK(s)**.
6. Android Studio will show the generated APK location, usually `app/build/outputs/apk/debug/app-debug.apk`.

## Important
This is a learning prototype, not a clinically validated medical device. Rhythm summaries are simplified and must be checked against current ECG/ACLS references and reviewed by a qualified clinician before educational or clinical deployment. Do not enter patient-identifiable data.

## Next development steps
- Expand to 30–50 rhythms with reviewed content
- Add ECG image cases and 12-lead interpretation practice
- Add 100+ reviewed MCQs, explanations and scoring
- Persist bookmarks and quiz progress locally
- Add accessibility, device testing and release signing

## Language selection
On first launch, the app asks the learner to choose **1. اردو** or **2. English**.
The choice is saved locally on the device and remembered on later launches.
The current starter build translates the main navigation and home/about interface;
the ECG rhythm names and technical explanations remain in English in this prototype.

## Chapter 01 content added

Added a first draft chapter, “Introduction to ECG”, based on the four handwritten notebook pages supplied by the user. The original notebook photos are retained in `source-notes/` for reference. Wording has been kept close to the notes, with light clarity edits. This project source has not been compiled into an APK in this environment because Android SDK/Gradle build tooling is not installed.
